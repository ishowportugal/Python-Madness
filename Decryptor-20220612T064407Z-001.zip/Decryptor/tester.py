from pcolor import colored
passtest=0
def dotest(isPass):
    global passtest
    passtest+=1
    if isPass:
        print(colored(f"Test {passtest} passed","green"))
    else:
        print(colored(f"Test {passtest} failed","red"))
        quit()